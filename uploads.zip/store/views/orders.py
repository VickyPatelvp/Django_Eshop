from django.shortcuts import render
from django.views import View
from store.models.orders import Orders

class OrdersView(View):

   def get(self,request):
       customer=request.session.get('customer')
       orders =Orders.get_all_orders_by_customer(customer)
       print(orders)
       return render(request,'orders.html',{'orders':orders})